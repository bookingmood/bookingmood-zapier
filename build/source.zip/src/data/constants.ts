export const baseUrl = `https://api.bookingmood.com/v1`;
