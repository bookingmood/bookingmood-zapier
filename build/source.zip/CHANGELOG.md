## 1.0.2

Update create/invite-member: Include user_profile in responses for member-related endpoints. This way users can see a name / email address instead of some opaque identifier.

## 1.0.3

Update trigger/members: Include user_profile in response.

## 1.0.4

Update trigger/members: Fix user_profile selector.

## 1.0.5

Update trigger/members: Add user_profile to sample data.

## 1.0.6

Update trigger/members: Fix user_profile sample data.

## 1.0.7

Add validation in account setup.
